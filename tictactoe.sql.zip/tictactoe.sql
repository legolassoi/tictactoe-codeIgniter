-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Час створення: Лют 11 2017 р., 21:26
-- Версія сервера: 5.1.69
-- Версія PHP: 5.4.25

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `tictactoe`
--

-- --------------------------------------------------------

--
-- Структура таблиці `game_results`
--

CREATE TABLE IF NOT EXISTS `game_results` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `player1_name` tinytext NOT NULL,
  `player2_name` tinytext NOT NULL,
  `winner` int(3) NOT NULL,
  `final_position` text NOT NULL,
  `played` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп даних таблиці `game_results`
--

INSERT INTO `game_results` (`id`, `player1_name`, `player2_name`, `winner`, `final_position`, `played`) VALUES
(1, 'Legolas', 'Nat', 1, '["O","O","X","","X","O","X","","X"]', '2017-02-11 21:25:22'),
(2, 'Legolas', 'AI opponent', 2, '["X","","X","","X","","O","O","O"]', '2017-02-11 21:26:12'),
(3, 'Legolas', 'AI opponent', 1, '["X","O","X","O","X","","O","","X"]', '2017-02-11 21:26:22');

-- --------------------------------------------------------

--
-- Структура таблиці `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `migrations`
--

INSERT INTO `migrations` (`version`) VALUES
(20170210234545);
